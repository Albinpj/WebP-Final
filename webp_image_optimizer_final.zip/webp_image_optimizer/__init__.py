# -*- coding: utf-8 -*-
from odoo import api, SUPERUSER_ID
from . import models


def abcd_abcd(cr, registry):
    env = api.Environment(cr, SUPERUSER_ID, {})
    for url_ids in env['ir.attachment'].search([('type', '=', 'url')]):
        url_ids.webp_type = str(url_ids.name.split('.')[1])
