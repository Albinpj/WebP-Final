{
    'name': 'WebP Image Optimizer',
    'version': '16.0.1.0.0',
    'summary': """Image To WebP""",
    'description': """Image To WebP""",
    'author': 'Cybrosys Techno Solutions',
    'company': 'Cybrosys Techno Solutions',
    'website': "https://www.cybrosys.com",
    'maintainer': 'Cybrosys Techno Solutions',
    'post_init_hook': 'abcd_abcd',
    'depends': ['base', 'website'],
    'data': [
        'views/website.xml'

    ],
    'license': 'LGPL-3',
    'price': 29,
    'currency': 'EUR',
    'installable': True,
    'auto_install': False,
    'application': False,
    'category': 'Website'
}
